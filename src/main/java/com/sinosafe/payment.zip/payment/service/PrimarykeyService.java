package com.sinosafe.payment.service;

/**
 * Created by zhuhuanmin on 2016/4/21.
 */
public interface PrimarykeyService {

    public Long getSeqence();

}
