package com.sinosafe.payment.service.impl;


import com.sinosafe.payment.service.RedisService;
import com.sinosafe.payment.service.RedisService;
import org.springframework.stereotype.Service;

/**
 * Created with base.
 * User: anguszhu
 * Date: Apr,07 2016
 * Time: 4:32 PM
 * description:
 */
@Service
public class RedisServiceImpl implements RedisService {




}
