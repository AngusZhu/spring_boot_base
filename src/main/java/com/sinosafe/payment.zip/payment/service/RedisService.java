package com.sinosafe.payment.service;

/**
 * Created with base.
 * User: anguszhu
 * Date: Apr,07 2016
 * Time: 4:29 PM
 * description:
 */
public interface RedisService  {




}
