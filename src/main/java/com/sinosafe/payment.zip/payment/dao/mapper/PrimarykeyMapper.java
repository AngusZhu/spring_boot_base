package com.sinosafe.payment.dao.mapper;

/**
 * Created by zhuhuanmin on 2016/4/21.
 */

public interface PrimarykeyMapper {

    Long getSeqence();

}
